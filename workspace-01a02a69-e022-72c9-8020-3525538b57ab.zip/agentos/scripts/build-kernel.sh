#!/usr/bin/env bash
# AgentOS kernel build: fetch (pinned) Linux LTS, configure, build bzImage.
#
# Everything lands in build/kernel/. The build directory is scratch and is
# regenerated from scratch by this script; the artifact that matters is
# build/kernel/bzImage-<version>.
#
# Environment overrides:
#   AGENTOS_KERNEL_VERSION  default: pinned version below
#   AGENTOS_KERNEL_URL      default: kernel.org CDN
#   AGENTOS_JOBS            default: nproc
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

AGENTOS_KERNEL_VERSION="${AGENTOS_KERNEL_VERSION:-6.12.104}"
AGENTOS_KERNEL_URL="${AGENTOS_KERNEL_URL:-https://cdn.kernel.org/pub/linux/kernel/v6.x}"
JOBS="${AGENTOS_JOBS:-$(nproc)}"

KERNEL_DIR="$ROOT/build/kernel/linux-$AGENTOS_KERNEL_VERSION"
OUT_DIR="$ROOT/build/kernel"
mkdir -p "$OUT_DIR"

TARBALL="$OUT_DIR/linux-$AGENTOS_KERNEL_VERSION.tar.xz"
if [ ! -f "$TARBALL" ]; then
  echo "[kernel] downloading linux-$AGENTOS_KERNEL_VERSION.tar.xz ..."
  curl -fL --retry 3 -o "$TARBALL" "$AGENTOS_KERNEL_URL/linux-$AGENTOS_KERNEL_VERSION.tar.xz"
fi
sha256sum "$TARBALL" | tee "$OUT_DIR/linux-$AGENTOS_KERNEL_VERSION.tar.xz.sha256"

if [ ! -d "$KERNEL_DIR" ]; then
  echo "[kernel] extracting ..."
  tar -C "$OUT_DIR" -xf "$TARBALL"
fi

cd "$KERNEL_DIR"
if [ ! -f .agentos_configured ]; then
  echo "[kernel] configuring (defconfig + AgentOS fragment) ..."
  make defconfig
  scripts/kconfig/merge_config.sh -m .config "$ROOT/kernel/config-x86_64" > /dev/null
  make olddefconfig
  # Verify a few load-bearing settings made it in.
  for opt in CONFIG_DEVTMPFS=y CONFIG_TMPFS=y CONFIG_DRM_VIRTIO_GPU=y CONFIG_DRM_BOCHS=y \
             CONFIG_FRAMEBUFFER_CONSOLE=y CONFIG_INPUT_EVDEV=y CONFIG_SERIAL_8250_CONSOLE=y \
             CONFIG_EFI_STUB=y CONFIG_ISO9660_FS=y CONFIG_UNIX98_PTYS=y CONFIG_SECCOMP_FILTER=y; do
    if ! grep -qx "$opt" .config; then
      echo "[kernel] FATAL: $opt missing after merge" >&2
      exit 1
    fi
  done
  if grep -qx 'CONFIG_MODULES=y' .config; then
    echo "[kernel] FATAL: modules were enabled; AgentOS kernel must be built-in only" >&2
    exit 1
  fi
  touch .agentos_configured
fi

echo "[kernel] building bzImage with -j$JOBS ..."
make -j"$JOBS" bzImage

cp -f arch/x86/boot/bzImage "$OUT_DIR/bzImage-$AGENTOS_KERNEL_VERSION"
echo "[kernel] kernel built: $OUT_DIR/bzImage-$AGENTOS_KERNEL_VERSION"
